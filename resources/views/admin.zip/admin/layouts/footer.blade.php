<footer>
  <div class="footer">
      <p class="m-0">Copyright © 2023 All rights reserved.</p>
  </div>
</footer>